# -*- coding: utf-8 -*-
#===============================================================================
import matplotlib.pyplot as plt
from scat_map import *

SM(domain_I, domain_theta , step_1)
plt.show()
