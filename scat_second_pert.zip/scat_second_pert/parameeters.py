# -*- coding: utf-8 -*-
#==============================================================
 #parameeters
# general programs
a_1 = 1.5
a_2 = 1.
eps = 0.01
mu = a_1/a_2
