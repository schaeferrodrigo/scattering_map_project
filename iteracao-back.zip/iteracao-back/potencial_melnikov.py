# -*- coding: utf-8 -*-
#===============================================================================
import numpy as np
import matplotlib.pyplot as plt
import sys
from parametros import *
from funcoes import *
#===============================================================================
# Melnikov Potential

def L( I_1 , I_2 , theta_1 , theta_2  , tau ):
    l = A(I_1 , a_1 , Omega_1 ) * np.cos( theta_1 - Omega_1 * I_1 * tau  ) + A( I_2 , a_2 , Omega_2 ) * np.cos( theta_2 - I_2 * Omega_2 * tau ) + A( 1. , 1. , 1. ) * np.cos( tau )
    return l

def part_der_L_I_1( I_1 , I_2 , theta_1 , theta_2 , tau):
    der = der_A(I_1 , a_1 , Omega_1) * np.cos(theta_1 - Omega_1 *I_1* tau) + A(I_1 , a_1 ,Omega_1) * tau * np.sin( theta_1- I_1 * Omega_1 *tau )
    return der

def part_der_L_I_2( I_1 , I_2 , theta_1 , theta_2 , tau):
    der = der_A(I_2, a_2,Omega_2) * np.cos( theta_2 - I_2 * Omega_2 * tau)  + A(I_2, a_2 , Omega_2) * tau *np.sin(theta_2 - I_2 * Omega_2 * tau )
    return der

def part_der_L_theta_1( I_1 , I_2 , theta_1 , theta_2  , tau ):
    der = -A(I_1, a_1, Omega_1 ) * np.sin( theta_1 - Omega_1 * I_1 * tau )
    return der

def part_der_L_theta_2( I_1 , I_2 , theta_1 , theta_2 , tau) :
    der = -A(I_2, a_2, Omega_2 ) * np.sin( theta_2 - Omega_2 * I_2 * tau )
    return der
#-------------------------------------------------------------------------------
