# -*- coding: utf-8 -*-
#===============================================================================
import numpy as np
#import matplotlib.pyplot as plt
#import sys
from parametros import *
#==========================================================
#functions

def A(I,a,omega):
    " funçoes coeficientes A_i"
    A = 2 * np.pi * I * omega * a/np.sinh(np.pi*I*omega/2)
    return A

def der_A(I,a,omega):
    "derivada de A_i"
    der = 2 * np.pi *omega* a * ( np.sinh( np.pi * omega*I / 2) - omega*I * (np.pi / 2)* np.cosh( np.pi * omega*I / 2)) /(np.sinh(np.pi * I *omega /2)**2)
    return der

#--------------------------------------------------------
